import { RouterContext } from "koa-router";

// Simple validation middleware for article data
export const validateArticle = async (ctx: RouterContext, next: any) => {
  const body: any = ctx.request.body;

  if (!body) {
    ctx.status = 400;
    ctx.body = { err: "Request body is required" };
    return;
  }

  if (!body.title || typeof body.title !== "string") {
    ctx.status = 400;
    ctx.body = { err: "Title is required and must be a string" };
    return;
  }

  if (!body.alltext || typeof body.alltext !== "string") {
    ctx.status = 400;
    ctx.body = { err: "Content (alltext) is required and must be a string" };
    return;
  }

  if (!body.authorid || typeof body.authorid !== "number") {
    ctx.status = 400;
    ctx.body = { err: "Author ID is required and must be a number" };
    return;
  }

  await next();
};
