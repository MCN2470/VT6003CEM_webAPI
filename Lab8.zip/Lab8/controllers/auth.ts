import { RouterContext } from "koa-router";

// Simple basic authentication for demo purposes
export const basicAuth = async (ctx: RouterContext, next: any) => {
  // For demo purposes, we'll accept any basic auth
  const auth = ctx.headers.authorization;

  if (!auth || !auth.startsWith("Basic ")) {
    ctx.status = 401;
    ctx.body = { err: "Authentication required" };
    return;
  }

  // In a real app, you would verify the credentials here
  await next();
};
