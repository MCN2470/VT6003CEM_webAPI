// Simple article model for Lab8 OpenAPI documentation demo

interface Article {
  id?: number;
  title: string;
  alltext: string;
  summary?: string;
  imageurl?: string;
  published?: boolean;
  authorid: number;
}

// Mock data
let articles: Article[] = [
  {
    id: 1,
    title: "First Article",
    alltext: "This is the content of the first article.",
    summary: "First article summary",
    published: true,
    authorid: 1,
  },
  {
    id: 2,
    title: "Second Article",
    alltext: "This is the content of the second article.",
    summary: "Second article summary",
    published: true,
    authorid: 1,
  },
];

let nextId = 3;

export const getAll = async () => {
  return articles;
};

export const getById = async (id: number) => {
  const article = articles.filter((a) => a.id === id);
  return article;
};

export const add = async (article: Article) => {
  article.id = nextId++;
  articles.push(article);
  return { status: 201, data: article };
};

export const update = async (updates: Partial<Article>, id: number) => {
  const index = articles.findIndex((a) => a.id === id);
  if (index !== -1) {
    articles[index] = { ...articles[index], ...updates };
    return true;
  }
  return false;
};

export const deleteById = async (id: number) => {
  const index = articles.findIndex((a) => a.id === id);
  if (index !== -1) {
    articles.splice(index, 1);
    return true;
  }
  return false;
};
