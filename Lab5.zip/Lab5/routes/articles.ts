import Router, { RouterContext } from "koa-router";
import bodyParser from "koa-bodyparser";

const router = new Router({ prefix: "/api/v1/articles" });

let articles = [
  {
    id: 1,
    title: "hello article",
    fullText: "some text here to fill the body",
    dateCreated: new Date(),
    dateModified: new Date(),
    views: 0,
    published: true,
    authorId: 1,
  },
  {
    id: 2,
    title: "another article",
    fullText: "again here is some text here to fill",
    dateCreated: new Date(),
    dateModified: new Date(),
    views: 10,
    published: true,
    authorId: 1,
  },
  {
    id: 3,
    title: "coventry university",
    fullText: "some news about coventry university",
    dateCreated: new Date(),
    dateModified: new Date(),
    views: 25,
    published: false,
    authorId: 2,
  },
  {
    id: 4,
    title: "smart campus",
    fullText: "smart campus is coming to IVE",
    dateCreated: new Date(),
    dateModified: new Date(),
    views: 5,
    published: true,
    authorId: 2,
  },
];

const getAll = async (ctx: RouterContext, next: any) => {
  ctx.body = articles;
  await next();
};

const getById = async (ctx: RouterContext, next: any) => {
  const id = +ctx.params.id;
  if (isNaN(id) || id <= 0) {
    ctx.status = 400;
    ctx.body = { error: "Invalid ID parameter" };
    return;
  }
  const article = articles.find((a) => a.id === id);
  if (article) {
    article.views++;
    ctx.body = article;
  } else {
    ctx.status = 404;
  }
  await next();
};

const createArticle = async (ctx: RouterContext, next: any) => {
  const body: any = ctx.request.body;
  const newArticle = {
    id: articles.length + 1,
    title: body.title,
    fullText: body.fullText,
    dateCreated: new Date(),
    dateModified: new Date(),
    views: 0,
    published: body.published || false,
    authorId: body.authorId || 1,
  };
  articles.push(newArticle);
  ctx.status = 201;
  ctx.body = newArticle;
  await next();
};

const updateArticle = async (ctx: RouterContext, next: any) => {
  const id = +ctx.params.id;
  if (isNaN(id) || id <= 0) {
    ctx.status = 400;
    ctx.body = { error: "Invalid ID parameter" };
    return;
  }
  const body: any = ctx.request.body;
  const index = articles.findIndex((a) => a.id === id);

  if (index === -1) {
    ctx.status = 404;
    return;
  }

  const updatedArticle = {
    ...articles[index],
    ...body,
    dateModified: new Date(),
  };
  articles[index] = updatedArticle;

  ctx.status = 200;
  ctx.body = updatedArticle;
  await next();
};

const deleteArticle = async (ctx: RouterContext, next: any) => {
  const id = +ctx.params.id;
  if (isNaN(id) || id <= 0) {
    ctx.status = 400;
    ctx.body = { error: "Invalid ID parameter" };
    return;
  }
  const index = articles.findIndex((a) => a.id === id);

  if (index === -1) {
    ctx.status = 404;
    return;
  }

  articles.splice(index, 1);
  ctx.status = 200;
  ctx.body = { message: `Article with id ${id} has been deleted.` };
  await next();
};

router.get("/", getAll);

router.post("/", bodyParser(), createArticle);

router.get("/:id", getById);

router.put("/:id", bodyParser(), updateArticle);

router.del("/:id", deleteArticle);

export { router };
