"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const koa_1 = __importDefault(require("koa"));
const koa_logger_1 = __importDefault(require("koa-logger"));
const koa_json_1 = __importDefault(require("koa-json"));
const koa_bodyparser_1 = __importDefault(require("koa-bodyparser"));
const koa_passport_1 = __importDefault(require("koa-passport"));
const articles_1 = require("./routes/articles");
const special_1 = require("./routes/special");
const app = new koa_1.default();
// Initialize Passport
app.use(koa_passport_1.default.initialize());
app.use((0, koa_logger_1.default)());
app.use((0, koa_json_1.default)());
app.use((0, koa_bodyparser_1.default)());
// Add routes
app.use(special_1.router.routes()).use(special_1.router.allowedMethods());
app.use(articles_1.router.routes()).use(articles_1.router.allowedMethods());
app.use((ctx, next) => __awaiter(void 0, void 0, void 0, function* () {
    try {
        yield next();
        console.log(ctx.status);
        if (ctx.status === 404) {
            ctx.body = { err: "Resource not found" };
        }
    }
    catch (err) {
        ctx.status = 500;
        ctx.body = { err: "Internal server error" };
        console.error("Server error:", err);
    }
}));
app.listen(10888, () => {
    console.log("Lab 7 - Koa Server with Authentication & Validation Started on port 10888");
    console.log("Available endpoints:");
    console.log("- GET /api/v1 - Public endpoint");
    console.log("- GET /api/v1/private - Protected endpoint (requires Basic Auth)");
    console.log("- GET /api/v1/articles - Get all articles (public)");
    console.log("- GET /api/v1/articles/:id - Get article by ID (public)");
    console.log("- POST /api/v1/articles - Create article (protected + validated)");
    console.log("- PUT /api/v1/articles/:id - Update article (protected + validated)");
    console.log("- DELETE /api/v1/articles/:id - Delete article (protected)");
});
