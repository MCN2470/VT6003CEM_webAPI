import Koa from "koa";
import Router, { RouterContext } from "koa-router";
import logger from "koa-logger";
import json from "koa-json";
import bodyParser from "koa-bodyparser";
import passport from "koa-passport";

import { router as articlesRouter } from "./routes/articles";
import { router as specialRouter } from "./routes/special";

const app: Koa = new Koa();

// Initialize Passport
app.use(passport.initialize());

app.use(logger());
app.use(json());
app.use(bodyParser());

// Add routes
app.use(specialRouter.routes()).use(specialRouter.allowedMethods());
app.use(articlesRouter.routes()).use(articlesRouter.allowedMethods());

app.use(async (ctx: RouterContext, next: any) => {
  try {
    await next();
    console.log(ctx.status);
    if (ctx.status === 404) {
      ctx.body = { err: "Resource not found" };
    }
  } catch (err: any) {
    ctx.status = 500;
    ctx.body = { err: "Internal server error" };
    console.error("Server error:", err);
  }
});

app.listen(10888, () => {
  console.log(
    "Lab 7 - Koa Server with Authentication & Validation Started on port 10888"
  );
  console.log("Available endpoints:");
  console.log("- GET /api/v1 - Public endpoint");
  console.log(
    "- GET /api/v1/private - Protected endpoint (requires Basic Auth)"
  );
  console.log("- GET /api/v1/articles - Get all articles (public)");
  console.log("- GET /api/v1/articles/:id - Get article by ID (public)");
  console.log(
    "- POST /api/v1/articles - Create article (protected + validated)"
  );
  console.log(
    "- PUT /api/v1/articles/:id - Update article (protected + validated)"
  );
  console.log("- DELETE /api/v1/articles/:id - Delete article (protected)");
});
