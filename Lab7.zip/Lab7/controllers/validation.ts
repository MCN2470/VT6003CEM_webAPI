import { Validator } from "jsonschema";
import { RouterContext } from "koa-router";
import { article } from "../schemas/article.schema";

const v = new Validator();

export const validateArticle = async (ctx: RouterContext, next: any) => {
  const body = ctx.request.body;
  const result = v.validate(body, article);

  if (!result.valid) {
    ctx.body = {
      message: "Validation failed",
      errors: result.errors,
    };
    ctx.status = 400;
    return;
  }

  await next();
};
