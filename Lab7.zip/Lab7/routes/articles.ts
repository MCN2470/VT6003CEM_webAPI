import Router, { RouterContext } from "koa-router";
import bodyParser from "koa-bodyparser";
import * as model from "../models/articles";
import { basicAuth } from "../controllers/auth";
import { validateArticle } from "../controllers/validation";

const router = new Router({ prefix: "/api/v1/articles" });

const getAll = async (ctx: RouterContext, next: any) => {
  let articles = await model.getAll();
  if (articles.length) {
    ctx.body = articles;
  } else {
    ctx.body = {};
  }
  await next();
};

const createArticle = async (ctx: RouterContext, next: any) => {
  const body = ctx.request.body;
  let result = await model.add(body);
  if (result.status == 201) {
    ctx.status = 201;
    ctx.body = body;
  } else {
    ctx.status = 500;
    ctx.body = { err: "insert data failed" };
  }
  await next();
};

const getById = async (ctx: RouterContext, next: any) => {
  let id = +ctx.params.id;

  if (isNaN(id) || id <= 0) {
    ctx.status = 400;
    ctx.body = { err: "Invalid ID parameter" };
    return;
  }

  let article = await model.getById(id);
  if (article.length) {
    ctx.body = article[0];
  } else {
    ctx.status = 404;
  }
  await next();
};

const updateArticle = async (ctx: RouterContext, next: any) => {
  let id = +ctx.params.id;
  let c: any = ctx.request.body;

  let result = await model.update(c, id);
  if (result) {
    ctx.status = 201;
    ctx.body = `Article with id ${id} updated`;
  }
  await next();
};

const deleteArticle = async (ctx: RouterContext, next: any) => {
  let id = +ctx.params.id;

  let article = await model.deleteById(id);
  ctx.status = 201;
  ctx.body = `Article with id ${id} deleted`;
  await next();
};

// Public routes (no authentication required)
router.get("/", getAll);
router.get("/:id", getById);

// Protected routes (authentication required)
router.post("/", bodyParser(), validateArticle, basicAuth, createArticle);
router.put("/:id", bodyParser(), validateArticle, basicAuth, updateArticle);
router.delete("/:id", basicAuth, deleteArticle);

export { router };
