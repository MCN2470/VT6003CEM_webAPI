import Router, { RouterContext } from "koa-router";
import { basicAuth } from "../controllers/auth";

const router = new Router({ prefix: "/api/v1" });

// Public route - accessible to everyone
router.get("/", async (ctx: RouterContext, next: any) => {
  ctx.body = {
    message: "Public API return",
  };
  await next();
});

// Protected route - requires authentication
router.get("/private", basicAuth);

export { router };
