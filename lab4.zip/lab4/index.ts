import Koa from "koa";
import Router, { RouterContext } from "koa-router";
import logger from "koa-logger";
import json from "koa-json";
import bodyParser from "koa-bodyparser";

const app: Koa = new Koa();
const router: Router = new Router();

let films = [
  { id: 1, title: "The Matrix", year: 1999, director: "Wachowskis" },
  { id: 2, title: "Inception", year: 2010, director: "Christopher Nolan" },
  { id: 3, title: "Dune", year: 2021, director: "Denis Villeneuve" },
];

// Validation helper functions
const validateCreateFilm = (data: any): string[] => {
  const errors: string[] = [];

  if (
    !data.title ||
    typeof data.title !== "string" ||
    data.title.trim().length === 0
  ) {
    errors.push("Title is required and must be a non-empty string.");
  }

  if (
    !data.year ||
    !Number.isInteger(data.year) ||
    data.year < 1888 ||
    data.year > new Date().getFullYear()
  ) {
    errors.push("Year must be a valid year between 1888 and current year.");
  }

  if (
    !data.director ||
    typeof data.director !== "string" ||
    data.director.trim().length < 2
  ) {
    errors.push("Director name is required and must be at least 2 characters.");
  }

  if (!data.id || !Number.isInteger(data.id)) {
    errors.push("ID must be an integer.");
  } else if (films.some((f) => f.id === data.id)) {
    errors.push("Film with this ID already exists.");
  }

  return errors;
};

const validateUpdateFilm = (data: any, id: number): string[] => {
  const errors: string[] = [];

  if (!Number.isInteger(id)) {
    errors.push("ID in URL must be an integer.");
  }

  if (
    data.title !== undefined &&
    (typeof data.title !== "string" || data.title.trim().length === 0)
  ) {
    errors.push("Title must be a non-empty string if provided.");
  }

  if (
    data.year !== undefined &&
    (!Number.isInteger(data.year) ||
      data.year < 1888 ||
      data.year > new Date().getFullYear())
  ) {
    errors.push(
      "Year must be a valid year between 1888 and current year if provided."
    );
  }

  if (
    data.director !== undefined &&
    (typeof data.director !== "string" || data.director.trim().length < 2)
  ) {
    errors.push("Director name must be at least 2 characters if provided.");
  }

  return errors;
};

router.get("/", async (ctx: RouterContext, next: any) => {
  ctx.body = { msg: "Hello world! Welcome to the Film API." };
  await next();
});

router.post("/", async (ctx: RouterContext, next: any) => {
  const data = ctx.request.body;
  ctx.body = data;
  await next();
});

router.get("/film", async (ctx: RouterContext, next: any) => {
  ctx.body = films;
  await next();
});

router.get("/film/:id", async (ctx: RouterContext, next: any) => {
  const id = parseInt(ctx.params.id);

  if (isNaN(id)) {
    ctx.status = 400; // Bad Request
    ctx.body = { error: "ID must be a valid integer" };
    return;
  }

  const film = films.find((f) => f.id === id);

  if (film) {
    ctx.body = film;
  } else {
    ctx.status = 404; // Not Found
    ctx.body = { error: "Film not found" };
  }
  await next();
});

router.post("/film", async (ctx: RouterContext, next: any) => {
  const data = ctx.request.body;
  const validationErrors = validateCreateFilm(data);

  if (validationErrors.length > 0) {
    ctx.status = 422;
    ctx.body = { errors: validationErrors };
    return;
  }

  const newFilm: any = ctx.request.body;
  films.push(newFilm);
  ctx.status = 201;
  ctx.body = newFilm;
  await next();
});

router.put("/film/:id", async (ctx: RouterContext, next: any) => {
  const id = parseInt(ctx.params.id);
  const data = ctx.request.body;
  const validationErrors = validateUpdateFilm(data, id);

  if (validationErrors.length > 0) {
    ctx.status = 422;
    ctx.body = { errors: validationErrors };
    return;
  }

  const index = films.findIndex((f) => f.id === id);

  if (index !== -1) {
    films[index] = { ...films[index], ...(data as any) };
    ctx.body = films[index];
  } else {
    ctx.status = 404;
    ctx.body = { error: "Film not found to update" };
  }
  await next();
});

app.use(json());
app.use(logger());
app.use(bodyParser());
app.use(router.routes()).use(router.allowedMethods());

app.use(async (ctx: RouterContext, next: any) => {
  try {
    await next();
    if (ctx.status === 404) {
      ctx.status = 404;
      ctx.body = { err: "No such endpoint or resource exists." };
    }
  } catch (err: any) {
    ctx.status = 500;
    ctx.body = { err: "An internal server error occurred." };
  }
});

app.listen(10888, () => {
  console.log("Koa server started and listening on port 10888");
});
