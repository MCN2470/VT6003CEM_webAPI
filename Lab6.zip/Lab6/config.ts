// config.ts
export const config = {
  host: "localhost",
  port: 5432,
  user: "postgres",
  password: "418418",
  database: "Lab6",
  connection_limit: 100,
};
