"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = void 0;
// config.ts
exports.config = {
    host: "localhost",
    port: 5432,
    user: "postgres",
    password: "418418",
    database: "Lab6",
    connection_limit: 100,
};
